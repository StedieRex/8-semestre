public class GeneralesBizantinos {
    public static void main(String[] args) {
        ByzantineProblem byzantineProblem = new ByzantineProblem(5,1);
        byzantineProblem.executeConsenus();
    }
    
}
